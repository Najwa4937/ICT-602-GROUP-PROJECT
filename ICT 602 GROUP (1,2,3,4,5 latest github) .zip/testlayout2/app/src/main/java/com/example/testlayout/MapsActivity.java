package com.example.testlayout;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.Vector;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    MarkerOptions marker;
    LatLng centerlocation;

    Vector<MarkerOptions> markerOptions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        centerlocation = new LatLng(3.0, 101);
        markerOptions = new Vector<>();

        markerOptions.add(new MarkerOptions().title("Hospital Yan")
                .position(new LatLng(5.82, 100.38))


        );

        markerOptions.add(new MarkerOptions().title("Hospital Sultan Abd Halim")
                .position(new LatLng(5.66, 100.517))


        );

        markerOptions.add(new MarkerOptions().title("Hospital Pantai Sungai Petani")
                .position(new LatLng(5.6726, 100.5132))


        );
        markerOptions.add(new MarkerOptions().title("Hospital Sultanah Bahiyah")
                .position(new LatLng(6.1488, 100.4064))


        );

        markerOptions.add(new MarkerOptions().title("Klinik Langkawi")
                .position(new LatLng(6.3217, 99.8499))


        );

        markerOptions.add(new MarkerOptions().title("Klinik Air Hangat")
                .position(new LatLng(6.4228, 99.8031))


        );

        markerOptions.add(new MarkerOptions().title("Klinik Dr Naga")
                .position(new LatLng(6.3278, 99.8408))


        );

        markerOptions.add(new MarkerOptions().title("Hospital Pulau Pinang")
                .position(new LatLng(5.4167, 100.3110))


        );

        markerOptions.add(new MarkerOptions().title("Penang Adventist Hospital")
                .position(new LatLng(5.4322, 100.3052))


        );

        markerOptions.add(new MarkerOptions().title("Hospital Amanjaya")
                .position(new LatLng(5.6726, 100.5131))


        );

        markerOptions.add(new MarkerOptions().title("Metro Specialist Hospital")
                .position(new LatLng(5.6291, 100.5100))


        );

        markerOptions.add(new MarkerOptions().title("Kedah Medical Center")
                .position(new LatLng(6.4188, 100.3694))


        );
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        // LatLng sydney = new LatLng(-34, 151);
        // mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));

        for (MarkerOptions mark: markerOptions) {

            mMap.addMarker(mark);
        }

        enableMyLocation();

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(centerlocation, 8));
    }

    // Add a marker in Sydney and move the camera
    // LatLng sydney = new LatLng(34, 151);
    // mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
    // mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));

    private void enableMyLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            if (mMap != null) {
                mMap.setMyLocationEnabled(true);
            }
        } else {
            String perms[]={"android.permission.ACCESS_FINE_LOCATION"};
            // Permission to access the location is missing. Show rationale and request permission
            ActivityCompat.requestPermissions(this, perms, 200);

        }
    }

}