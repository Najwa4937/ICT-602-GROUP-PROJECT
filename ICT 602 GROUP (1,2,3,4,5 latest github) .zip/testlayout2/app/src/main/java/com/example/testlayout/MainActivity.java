package com.example.testlayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    GoogleSignInOptions gso;
    GoogleSignInClient mGoogleSignInClient;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        // Build a GoogleSignInClient with the options specified by gso.
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        // Check for existing Google Sign In account, if the user is already signed in
        // the GoogleSignInAccount will be non-null.
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);

        if (account == null) {
            //null: the user haven't sign in yet
            //user tak sign in lagi kalau null

            Toast.makeText(this,"Please sign in with Gmail account", Toast.LENGTH_SHORT).show();

        } else {
            //user already signin, so show the secret page.
            Intent intent = new Intent(this, RahsiaActivity.class);
            intent.putExtra("Name", account.getDisplayName());
            intent.putExtra("Email",account.getEmail());

            startActivity(intent);
        }

    }

    //link ke about page
    public void perform_about(View view)
    {
        Intent intentabout = new Intent(this, AboutActivity.class );
        startActivity(intentabout);
    }

    //link ke map with marker
    public void perform_location(View view){

        Intent intentlocation = new Intent();
        intentlocation.setClass(getApplicationContext(),MapsActivity.class);
        startActivity(intentlocation);
    }

    /*link ke login page
    public void perform_login(View view){
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, 10);
    } */

    public void onClick(View v) {
        switch (v.getId()){

            case R.id.sign_in_button:
                Intent signInIntent = mGoogleSignInClient.getSignInIntent();
                startActivityForResult(signInIntent, 10);
                break;
        }
        //send ke activity_main.xml
        Intent intentlayout = new Intent(this, LayoutActivity.class );
        startActivity(intentlayout);
    }
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == 10) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);

            // Signed in successfully, show authenticated UI.
            //buka activity baru yg rahsia tadi tu...
            Toast.makeText(this, "Already Sign In",Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(this, LayoutActivity.class);
            intent.putExtra("Name", account.getDisplayName());
            intent.putExtra("Email",account.getEmail());

            startActivity(intent);

        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Log.w("ALAMAK", "signInResult:failed code=" + e.getStatusCode());

            //takboleh sign in....
            Toast.makeText(this, "Alamak, takboleh sign in laa..",Toast.LENGTH_SHORT).show();

            //updateUI(null);
        }
    }

    //link ke geolocation
    public void perform_geolocation(View view){

        Intent intentgeo = new Intent(this, GeolocationActivity.class );
        startActivity(intentgeo);
    }




}